package br.com.plugitin.simpleexcelimport

enum CellType {
	NUMERIC,
	STRING,
	DATE;
}
