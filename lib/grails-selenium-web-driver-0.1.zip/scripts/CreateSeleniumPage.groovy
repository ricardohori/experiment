/*
 * Copyright 2010 Rob Fletcher
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

includeTargets << grailsScript("_GrailsInit")
includeTargets << grailsScript("_GrailsCreateArtifacts")

target(main: "Creates a new Grails Selenium RC page") {
	depends(checkVersion, parseArguments)

    promptForName(type: "Page")

    def name = argsMap["params"][0]
    createSeleniumPage(name: name, suffix: "")
}

createSeleniumPage = { Map args = [:] ->
    def superClass = args["superClass"] ?: "Page"
	def template = "SeleniumPage"
	createArtifact(name: args["name"], suffix: "Page", type: template, path: "test/selenium", superClass: superClass)
}

setDefaultTarget(main)
