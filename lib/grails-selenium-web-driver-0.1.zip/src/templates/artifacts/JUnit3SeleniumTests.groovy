@artifact.package@import grails.plugins.selenium.*

@Mixin(SeleniumAware)
class @artifact.name@ extends @artifact.superclass@ {
    void setUp() {
        super.setUp()
    }

    void tearDown() {
        super.tearDown()
    }

    void testSomething() {

    }
}
